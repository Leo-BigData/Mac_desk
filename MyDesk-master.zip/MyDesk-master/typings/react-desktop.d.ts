declare module "react-desktop/macOs" {
  export const View: any;
  export const Radio: any;
  export const TitleBar: any;
  export const Toolbar: any;
  export const Text: any;
  export const Box: any;
  export const ListView: any;
  export const ListViewRow: any;
  export const Window: any;
  export const Dialog: any;
  export const Button: any;
  export const Checkbox: any;
}
