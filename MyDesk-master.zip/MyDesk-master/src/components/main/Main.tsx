import React from 'react'
import './index.scss'

const Main = () => {
  return (
    <div className="AppMain">
      <div id="main-view" />
    </div>
  )
}

export default Main
